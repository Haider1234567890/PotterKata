<https://codingdojo.org/kata/Potter/>
